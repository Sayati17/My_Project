import React from "react";
import Header from "../components/Layout/Header";

const ReviewsPage = () => {
  return (
    <div>
      <Header activeHeading={3} />
    </div>
  );
};

export default ReviewsPage;
